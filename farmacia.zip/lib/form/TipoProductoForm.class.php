<?php

/**
 * TipoProducto form.
 *
 * @package    universidad
 * @subpackage form
 * @author     Univ
 */
class TipoProductoForm extends BaseTipoProductoForm
{
  public function configure()
  {
  }
}
