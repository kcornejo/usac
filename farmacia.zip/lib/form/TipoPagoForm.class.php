<?php

/**
 * TipoPago form.
 *
 * @package    universidad
 * @subpackage form
 * @author     Univ
 */
class TipoPagoForm extends BaseTipoPagoForm
{
  public function configure()
  {
  }
}
