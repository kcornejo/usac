<?php

/**
 * Cliente form.
 *
 * @package    universidad
 * @subpackage form
 * @author     Univ
 */
class ClienteForm extends BaseClienteForm
{
  public function configure()
  {
  }
}
