<?php

/**
 * TipoTransaccion form.
 *
 * @package    universidad
 * @subpackage form
 * @author     Univ
 */
class TipoTransaccionForm extends BaseTipoTransaccionForm
{
  public function configure()
  {
  }
}
