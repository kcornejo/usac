<?php

/**
 * Turno form.
 *
 * @package    universidad
 * @subpackage form
 * @author     Univ
 */
class TurnoForm extends BaseTurnoForm
{
  public function configure()
  {
  }
}
