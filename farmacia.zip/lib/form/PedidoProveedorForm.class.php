<?php

/**
 * PedidoProveedor form.
 *
 * @package    universidad
 * @subpackage form
 * @author     Univ
 */
class PedidoProveedorForm extends BasePedidoProveedorForm
{
  public function configure()
  {
  }
}
