<?php

/**
 * Promocion form.
 *
 * @package    universidad
 * @subpackage form
 * @author     Univ
 */
class PromocionForm extends BasePromocionForm
{
  public function configure()
  {
  }
}
