<?php

/**
 * Proveedor form.
 *
 * @package    universidad
 * @subpackage form
 * @author     Univ
 */
class ProveedorForm extends BaseProveedorForm
{
  public function configure()
  {
  }
}
