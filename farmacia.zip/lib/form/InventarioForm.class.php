<?php

/**
 * Inventario form.
 *
 * @package    universidad
 * @subpackage form
 * @author     Univ
 */
class InventarioForm extends BaseInventarioForm
{
  public function configure()
  {
  }
}
