<?php

/**
 * Producto form.
 *
 * @package    universidad
 * @subpackage form
 * @author     Univ
 */
class ProductoForm extends BaseProductoForm
{
  public function configure()
  {
  }
}
