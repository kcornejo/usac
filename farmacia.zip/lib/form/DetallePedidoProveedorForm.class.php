<?php

/**
 * DetallePedidoProveedor form.
 *
 * @package    universidad
 * @subpackage form
 * @author     Univ
 */
class DetallePedidoProveedorForm extends BaseDetallePedidoProveedorForm
{
  public function configure()
  {
  }
}
