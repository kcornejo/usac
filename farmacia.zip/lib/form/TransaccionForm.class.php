<?php

/**
 * Transaccion form.
 *
 * @package    universidad
 * @subpackage form
 * @author     Univ
 */
class TransaccionForm extends BaseTransaccionForm
{
  public function configure()
  {
  }
}
