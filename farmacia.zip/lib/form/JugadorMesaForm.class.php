<?php

/**
 * JugadorMesa form.
 *
 * @package    universidad
 * @subpackage form
 * @author     Univ
 */
class JugadorMesaForm extends BaseJugadorMesaForm
{
  public function configure()
  {
  }
}
