<?php

/**
 * Usuario form.
 *
 * @package    plan
 * @subpackage form
 * @author     via
 */
class UsuarioForm extends BaseUsuarioForm
{
  public function configure()
  {
  }
}
