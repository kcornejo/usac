<?php

/**
 * Project form base class.
 *
 * @package    plan
 * @subpackage form
 * @author     via
 */
abstract class BaseFormPropel extends sfFormPropel
{
  public function setup()
  {
  }
}
