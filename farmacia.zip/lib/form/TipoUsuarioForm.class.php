<?php

/**
 * TipoUsuario form.
 *
 * @package    universidad
 * @subpackage form
 * @author     Univ
 */
class TipoUsuarioForm extends BaseTipoUsuarioForm
{
  public function configure()
  {
  }
}
