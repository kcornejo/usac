<?php

/**
 * Jugador form.
 *
 * @package    universidad
 * @subpackage form
 * @author     Univ
 */
class JugadorForm extends BaseJugadorForm
{
  public function configure()
  {
  }
}
