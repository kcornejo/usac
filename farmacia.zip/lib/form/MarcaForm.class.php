<?php

/**
 * Marca form.
 *
 * @package    universidad
 * @subpackage form
 * @author     Univ
 */
class MarcaForm extends BaseMarcaForm
{
  public function configure()
  {
  }
}
