<?php

/**
 * Mesa form.
 *
 * @package    universidad
 * @subpackage form
 * @author     Univ
 */
class MesaForm extends BaseMesaForm
{
  public function configure()
  {
  }
}
