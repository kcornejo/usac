<?php

/**
 * Cliente filter form.
 *
 * @package    universidad
 * @subpackage filter
 * @author     Univ
 */
class ClienteFormFilter extends BaseClienteFormFilter
{
  public function configure()
  {
  }
}
