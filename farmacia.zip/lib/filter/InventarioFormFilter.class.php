<?php

/**
 * Inventario filter form.
 *
 * @package    universidad
 * @subpackage filter
 * @author     Univ
 */
class InventarioFormFilter extends BaseInventarioFormFilter
{
  public function configure()
  {
  }
}
