<?php

/**
 * Turno filter form.
 *
 * @package    universidad
 * @subpackage filter
 * @author     Univ
 */
class TurnoFormFilter extends BaseTurnoFormFilter
{
  public function configure()
  {
  }
}
