<?php

/**
 * DetallePedidoProveedor filter form.
 *
 * @package    universidad
 * @subpackage filter
 * @author     Univ
 */
class DetallePedidoProveedorFormFilter extends BaseDetallePedidoProveedorFormFilter
{
  public function configure()
  {
  }
}
