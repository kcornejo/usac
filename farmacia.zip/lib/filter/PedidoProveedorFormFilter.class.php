<?php

/**
 * PedidoProveedor filter form.
 *
 * @package    universidad
 * @subpackage filter
 * @author     Univ
 */
class PedidoProveedorFormFilter extends BasePedidoProveedorFormFilter
{
  public function configure()
  {
  }
}
