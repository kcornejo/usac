<?php

/**
 * Promocion filter form.
 *
 * @package    universidad
 * @subpackage filter
 * @author     Univ
 */
class PromocionFormFilter extends BasePromocionFormFilter
{
  public function configure()
  {
  }
}
