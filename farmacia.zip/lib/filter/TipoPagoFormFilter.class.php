<?php

/**
 * TipoPago filter form.
 *
 * @package    universidad
 * @subpackage filter
 * @author     Univ
 */
class TipoPagoFormFilter extends BaseTipoPagoFormFilter
{
  public function configure()
  {
  }
}
