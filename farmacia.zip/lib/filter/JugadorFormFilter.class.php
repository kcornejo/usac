<?php

/**
 * Jugador filter form.
 *
 * @package    universidad
 * @subpackage filter
 * @author     Univ
 */
class JugadorFormFilter extends BaseJugadorFormFilter
{
  public function configure()
  {
  }
}
