<?php

/**
 * Producto filter form.
 *
 * @package    universidad
 * @subpackage filter
 * @author     Univ
 */
class ProductoFormFilter extends BaseProductoFormFilter
{
  public function configure()
  {
  }
}
