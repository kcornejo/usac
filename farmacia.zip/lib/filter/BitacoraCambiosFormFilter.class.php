<?php

/**
 * BitacoraCambios filter form.
 *
 * @package    universidad
 * @subpackage filter
 * @author     Univ
 */
class BitacoraCambiosFormFilter extends BaseBitacoraCambiosFormFilter
{
  public function configure()
  {
  }
}
