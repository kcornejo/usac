<?php

/**
 * TipoUsuario filter form.
 *
 * @package    universidad
 * @subpackage filter
 * @author     Univ
 */
class TipoUsuarioFormFilter extends BaseTipoUsuarioFormFilter
{
  public function configure()
  {
  }
}
