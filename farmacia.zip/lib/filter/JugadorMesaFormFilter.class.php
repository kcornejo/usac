<?php

/**
 * JugadorMesa filter form.
 *
 * @package    universidad
 * @subpackage filter
 * @author     Univ
 */
class JugadorMesaFormFilter extends BaseJugadorMesaFormFilter
{
  public function configure()
  {
  }
}
