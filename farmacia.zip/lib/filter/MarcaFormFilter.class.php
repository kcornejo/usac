<?php

/**
 * Marca filter form.
 *
 * @package    universidad
 * @subpackage filter
 * @author     Univ
 */
class MarcaFormFilter extends BaseMarcaFormFilter
{
  public function configure()
  {
  }
}
