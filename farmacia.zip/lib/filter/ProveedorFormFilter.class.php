<?php

/**
 * Proveedor filter form.
 *
 * @package    universidad
 * @subpackage filter
 * @author     Univ
 */
class ProveedorFormFilter extends BaseProveedorFormFilter
{
  public function configure()
  {
  }
}
