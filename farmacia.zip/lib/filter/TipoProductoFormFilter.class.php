<?php

/**
 * TipoProducto filter form.
 *
 * @package    universidad
 * @subpackage filter
 * @author     Univ
 */
class TipoProductoFormFilter extends BaseTipoProductoFormFilter
{
  public function configure()
  {
  }
}
