<?php

/**
 * Usuario filter form.
 *
 * @package    plan
 * @subpackage filter
 * @author     via
 */
class UsuarioFormFilter extends BaseUsuarioFormFilter
{
  public function configure()
  {
  }
}
