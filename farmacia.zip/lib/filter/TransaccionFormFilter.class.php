<?php

/**
 * Transaccion filter form.
 *
 * @package    universidad
 * @subpackage filter
 * @author     Univ
 */
class TransaccionFormFilter extends BaseTransaccionFormFilter
{
  public function configure()
  {
  }
}
