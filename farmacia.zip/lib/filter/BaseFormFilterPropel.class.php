<?php

/**
 * Project filter form base class.
 *
 * @package    plan
 * @subpackage filter
 * @author     via
 */
abstract class BaseFormFilterPropel extends sfFormFilterPropel
{
  public function setup()
  {
  }
}
