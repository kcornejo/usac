<?php

/**
 * TipoTransaccion filter form.
 *
 * @package    universidad
 * @subpackage filter
 * @author     Univ
 */
class TipoTransaccionFormFilter extends BaseTipoTransaccionFormFilter
{
  public function configure()
  {
  }
}
