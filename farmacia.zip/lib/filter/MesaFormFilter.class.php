<?php

/**
 * Mesa filter form.
 *
 * @package    universidad
 * @subpackage filter
 * @author     Univ
 */
class MesaFormFilter extends BaseMesaFormFilter
{
  public function configure()
  {
  }
}
