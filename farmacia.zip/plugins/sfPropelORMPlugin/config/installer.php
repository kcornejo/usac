<?php

$this->installDir(dirname(__FILE__).'/skeleton');
$this->enablePlugin('sfPropelORMPlugin');
$this->reloadTasks();
