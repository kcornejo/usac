[?php

/**
 * <?php echo $this->table->getClassname() ?> form.
 *
 * @package    ##PROJECT_NAME##
 * @subpackage form
 * @author     ##AUTHOR_NAME##
 */
class <?php echo $this->table->getClassname() ?>Form extends Base<?php echo $this->table->getClassname() ?>Form
{
  public function configure()
  {
  }
}
