[?php

/**
 * Project form base class.
 *
 * @package    ##PROJECT_NAME##
 * @subpackage form
 * @author     ##AUTHOR_NAME##
 */
abstract class BaseFormPropel extends sfFormPropel
{
  public function setup()
  {
  }
}
